import random
pc = 2
def roll(player):
    #lis=[1,2,3,4,5,6]
    num=random.randint(1, 6)
    print(f"player {player}you have got {num} value")

while True:
    print("Do you want to play the game")
    choice = input("Yes/no")
    if choice in "yes":
        print("How many players")
        nop = int(input("Enter in numbers:"))
        while pc != 0:
            for player in range(1, nop+1):
                print(f"Do you want to roll the dice player {player}")
                pc = int(input("Enter 1 to roll 0 to exit"))
                if pc == 1:                                                                               b
                roll(player)
                elif pc == 0:
                    break
                else:
                    print("Invalid choice")

    elif choice in "no":
        break
    else:
        print("Invalid choice")
