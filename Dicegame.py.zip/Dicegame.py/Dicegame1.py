import random
pc = 2
def roll(player):
    num = random.randint(1,6)
    print(f"player {player} you have got {num} value ")

while True:
    print("Do you want to play the game ")
    choice = input("yes/no:")
    if choice in "yes":
        print("How many players:")
        nop = int(input("In numbers:"))
        while pc !=0:
            for player in range(1, nop+1):
                print(f"Do you want to role the dice {player}")
                pc = int(input("enter 1 to roll, 0 to exit"))
                if pc == 1:
                    roll(player)
                elif pc == 0:
                    break
                else:
                    print("Invalid choice")
    elif choice in "no":
        break
    else:
        print("Invalid choice")