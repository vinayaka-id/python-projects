import random

# Define the function to roll the dice
def roll_dice():
  """Rolls two dice and returns the results."""
  die1 = random.randint(1, 6)
  die2 = random.randint(1, 6)
  return die1, die2

# Define the function to play the game
def play_game():
  """Plays a game of dice."""
  # Get the player's name
  player_name = input("What is your name? ")

  # Roll the dice
  die1, die2 = roll_dice()

  # Calculate the total score
  total_score = die1 + die2

  # Print the results
  print(f"{player_name} rolled a {die1} and a {die2} for a total of {total_score}.")

# Play the game
play_game()